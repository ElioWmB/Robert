//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport
import AVFoundation


var audioPlayer: AVAudioPlayer?

func playSound(sound: String, type: String) {
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.play()
        } catch {
            print("Non funzionaaaaaa")
        }
    }
}





let robert1 = ["[???]: Yay Taco, I really love it." , "[???]: Yaay Pizza, every good story starts with it." , "Uhuh Salad, I love healthy food" , "[???]: Oh good, Sandwich. I like it."]

let robertText1 = UILabel(frame: CGRect(x: 30, y: 340, width: 300, height: 300))


robertText1.textColor = .white
robertText1.shadowColor = .black
robertText1.shadowOffset = .init(width: 1, height: 0.5)
robertText1.backgroundColor = .clear
robertText1.font = UIFont(name: "Helvetica", size: 18)
robertText1.textAlignment = .left
robertText1.numberOfLines = 0

let robert2 = "[???]: Mhhh, all the answers are almost the same."

let robertText2 = UILabel(frame: CGRect(x: 30, y: 390, width: 300, height: 300))


robertText2.textColor = .white
robertText2.shadowColor = .black
robertText2.shadowOffset = .init(width: 1, height: 0.5)
robertText2.backgroundColor = .clear
robertText2.font = UIFont(name: "Helvetica", size: 18)
robertText2.textAlignment = .left
robertText2.numberOfLines = 0



let eat = "Hello user, what do you want to eat today?"



let eatText = UILabel(frame: CGRect(x: 25, y: -50, width: 300, height: 300))


eatText.textColor = .systemGreen
eatText.shadowColor = .black
eatText.shadowOffset = .init(width: 1, height: 0.5)
eatText.backgroundColor = .clear
eatText.font = UIFont(name: "Courier", size: 18)
eatText.textAlignment = .left
eatText.numberOfLines = 0

let domanda = "How do you feel today?"

let domandaText = UILabel(frame: CGRect(x: 25, y: 130, width: 300, height: 300))


domandaText.textColor = .systemGreen
domandaText.shadowColor = .black
domandaText.shadowOffset = .init(width: 1, height: 0.5)
domandaText.backgroundColor = .clear
domandaText.font = UIFont(name: "Courier", size: 18)
domandaText.textAlignment = .left
domandaText.numberOfLines = 0

let loading = ["Food is loading, waiting_question initialized","Meal_cooking_process completed"]

let loadingText = UILabel(frame: CGRect(x: 30, y: 87, width: 300, height: 300))


loadingText.textColor = .systemGreen
loadingText.shadowColor = .black
loadingText.shadowOffset = .init(width: 1, height: 0.5)
loadingText.backgroundColor = .clear
loadingText.font = UIFont(name: "Courier-Oblique", size: 11)
loadingText.textAlignment = .left
loadingText.numberOfLines = 0

let banner = "T.A.R.S.app_routine_"

let bannerText = UILabel(frame: CGRect(x:25, y: -100, width:300,height: 300))

bannerText.textColor = .systemGreen
bannerText.shadowColor = .black
bannerText.shadowOffset = .init(width: 1, height: 0.5)
bannerText.backgroundColor = .clear
bannerText.font = UIFont(name: "Courier-Bold", size: 13)
bannerText.textAlignment = .left
bannerText.numberOfLines = 0
bannerText.text = banner

let tvPictures: [UIImage] =
[
        UIImage(named: "tv1.png")!, UIImage(named: "tv2.png")!, UIImage(named: "tv3.png")!,
        UIImage(named:"tv4.png")!, UIImage(named: "tv5.png")!, UIImage(named: "tv6.png")!,
        UIImage(named: "tv7.png")!, UIImage(named:"tv8.png")!, UIImage(named: "tv9.png")!, UIImage(named: "tv10.png")!, UIImage(named: "tv11.png")!, UIImage(named:"tv12.png")!,
        UIImage(named: "tv13.png")!, UIImage(named: "tv14.png")!,

]
//animation
var tvView = UIImageView(frame: CGRect(x: CGFloat(00), y: CGFloat(00), width: CGFloat(360), height: CGFloat(680)))
tvView.animationImages = tvPictures
tvView.animationDuration = 0.7
tvView.animationRepeatCount = 1





let animationPictures: [UIImage] =
[
        UIImage(named: "1.png")!, UIImage(named: "2.png")!, UIImage(named: "3.png")!,
        UIImage(named:"4.png")!, UIImage(named: "5.png")!, UIImage(named: "6.png")!,
        UIImage(named: "7.png")!, UIImage(named:"8.png")!, UIImage(named: "9.png")!, UIImage(named: "10.png")!, UIImage(named: "11.png")!, UIImage(named:"12.png")!,
        UIImage(named: "13.png")!, UIImage(named: "14.png")!, UIImage(named: "15.png")!,
        UIImage(named:"16.png")!, UIImage(named: "17.png")!, UIImage(named:"18.png")!,
        UIImage(named: "19.png")!, UIImage(named: "20.png")!, UIImage(named: "21.png")!,
        UIImage(named:"22.png")!, UIImage(named: "23.png")!, UIImage(named: "24.png")!,
        UIImage(named: "25.png")!, UIImage(named:"26.png")!, UIImage(named: "27.png")!, UIImage(named:"26.png")!,  UIImage(named: "25.png")!, UIImage(named: "24.png")!,  UIImage(named: "23.png")!,  UIImage(named:"22.png")!, UIImage(named: "21.png")!, UIImage(named: "20.png")!,
        UIImage(named: "19.png")!, UIImage(named:"18.png")!,
        UIImage(named: "17.png")!, UIImage(named:"16.png")!,
        UIImage(named: "15.png")!, UIImage(named: "14.png")!, UIImage(named: "13.png")!, UIImage(named:"12.png")!, UIImage(named: "11.png")!, UIImage(named: "10.png")!, UIImage(named: "9.png")!, UIImage(named: "8.png")!, UIImage(named: "7.png")!,
        UIImage(named:"6.png")!, UIImage(named: "5.png")!, UIImage(named: "4.png")!,
        UIImage(named: "3.png")!, UIImage(named:"2.png")!, UIImage(named: "1.png")!,

]
//animation
var animationView = UIImageView(frame: CGRect(x: CGFloat(30), y: CGFloat(200), width: CGFloat(300), height: CGFloat(20)))
animationView.animationImages = animationPictures
animationView.animationDuration = 1.5
animationView.animationRepeatCount = 0
animationView.startAnimating()


var variable = 0

class MyViewController : UIViewController {
    
    var loadingcompleta:UIImageView!
    var animazione:UIImageView!
//    var layout:UIImageView!
    var whiteroom:UIImageView!
    var taco:UIImageView!
    var pizza:UIImageView!
    var salad:UIImageView!
    var sandwich:UIImageView!
    let button = UIButton()
    let buttonpizza = UIButton()
    let buttontaco = UIButton()
    let buttonsalad = UIButton ()
    let buttonsandwich = UIButton ()
    let button2 = UIButton()
    let button3 = UIButton()
    let button4 = UIButton()
    let button5 = UIButton()

    
    
    override func loadView() {
        
    let view = UIView()
        view.backgroundColor = .black
        
        
//        layout = UIImageView()
//        layout.image = UIImage(named: "boh_Tavola disegno 1.png")
//        layout.frame = CGRect(x: 0, y: -10, width: 380, height: 680)
//        view.addSubview(layout)
//
        view.addSubview(bannerText)
        loadingcompleta = UIImageView()
        loadingcompleta.image = UIImage(named: "100.png")
        loadingcompleta.frame = CGRect(x: 30, y: 200, width: 300, height: 20)
        loadingcompleta.alpha = 0.0
        view.addSubview(loadingcompleta)
        
        
        whiteroom = UIImageView()
        whiteroom.image = UIImage(named: "untitled.png")
        whiteroom.frame = CGRect(x: -450, y: -50, width: 1300, height: 800)
        view.addSubview(whiteroom)
        
        taco = UIImageView()
        taco.image = UIImage(named: "taco.png")
        taco.frame = CGRect(x: 60, y: 135, width: 40, height: 40)
        taco.alpha = 0.0
        view.addSubview(taco)
        
        pizza = UIImageView()
        pizza.image = UIImage(named: "pizza.png")
        pizza.frame = CGRect(x: 130, y: 135, width: 40, height: 40)
        pizza.alpha = 0.0
        view.addSubview(pizza)
        
        salad = UIImageView()
        salad.image = UIImage(named: "salad.png")
        salad.frame = CGRect(x: 200, y: 135, width: 40, height: 40)
        salad.alpha = 0.0
        view.addSubview(salad)
        
        sandwich = UIImageView()
        sandwich.image = UIImage(named: "sandwich.png")
        sandwich.frame = CGRect(x: 270, y: 135, width: 40, height: 40)
        sandwich.alpha = 0.0
        view.addSubview(sandwich)
        
        
        button.setTitle(">", for: .normal)
        button.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button.setTitleColor(.darkGray, for: .normal)
        button.frame = CGRect(x: 300, y: 600, width: 50, height: 50)
        button.backgroundColor = .clear
        button.layer.borderColor = .init(srgbRed: 55, green: 55, blue: 55, alpha: 1.0)
        button.layer.borderWidth = 2
        button.layer.cornerRadius = 10
        
        view.addSubview(button)
        
        buttontaco.setTitle("  ", for: .normal)
        buttontaco.titleLabel?.font = UIFont(name: "Courier", size: 18)
        buttontaco.setTitleColor(.green, for: .normal)
        buttontaco.frame = CGRect(x: 50, y: 125, width: 60, height: 60)
        buttontaco.backgroundColor = .clear
        buttontaco.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        buttontaco.layer.borderWidth = 2
        buttontaco.layer.cornerRadius = 10
        buttontaco.alpha = 0.0
        
        view.addSubview(buttontaco)
        
        
        
        buttonpizza.setTitle("  ", for: .normal)
        buttonpizza.titleLabel?.font = UIFont(name: "Courier", size: 18)
        buttonpizza.setTitleColor(.green, for: .normal)
        buttonpizza.frame = CGRect(x: 120, y: 125, width: 60, height: 60)
        buttonpizza.backgroundColor = .clear
        buttonpizza.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        buttonpizza.layer.borderWidth = 2
        buttonpizza.layer.cornerRadius = 10
        buttonpizza.alpha = 0.0
        
        view.addSubview(buttonpizza)
        
        buttonsalad.setTitle("  ", for: .normal)
        buttonsalad.titleLabel?.font = UIFont(name: "Courier", size: 18)
        buttonsalad.setTitleColor(.green, for: .normal)
        buttonsalad.frame = CGRect(x: 190, y: 125, width: 60, height: 60)
        buttonsalad.backgroundColor = .clear
        buttonsalad.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        buttonsalad.layer.borderWidth = 2
        buttonsalad.layer.cornerRadius = 10
        buttonsalad.alpha = 0.0
        
        view.addSubview(buttonsalad)
        
        buttonsandwich.setTitle("  ", for: .normal)
        buttonsandwich.titleLabel?.font = UIFont(name: "Courier", size: 18)
        buttonsandwich.setTitleColor(.green, for: .normal)
        buttonsandwich.frame = CGRect(x: 260, y: 125, width: 60, height: 60)
        buttonsandwich.backgroundColor = .clear
        buttonsandwich.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        buttonsandwich.layer.borderWidth = 2
        buttonsandwich.layer.cornerRadius = 10
        buttonsandwich.alpha = 0.0
        
        view.addSubview(buttonsandwich)
        
        
        button2.setTitle("• Nice", for: .normal)
        button2.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button2.setTitleColor(.systemGreen , for: .normal)
        button2.frame = CGRect(x: 12, y:300, width: 90, height: 40)
        button2.backgroundColor = .clear
        button2.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        button2.layer.borderWidth = 2
        button2.layer.cornerRadius = 10
        button2.alpha = 0.0
        
        view.addSubview(button2)
        
        
        button3.setTitle("• Great", for: .normal)
        button3.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button3.setTitleColor(.systemGreen , for: .normal)
        button3.frame = CGRect(x: 17, y: 340, width: 90, height: 40)
        button3.backgroundColor = .clear
        button3.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        button3.layer.borderWidth = 2
        button3.layer.cornerRadius = 10
        button3.alpha = 0.0
        view.addSubview(button3)
        
        
        button4.setTitle("• Good", for: .normal)
        button4.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button4.setTitleColor(.systemGreen , for: .normal)
        button4.frame = CGRect(x: 150, y: 300, width: 90, height: 40)
        button4.backgroundColor = .clear
        button4.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        button4.layer.borderWidth = 2
        button4.layer.cornerRadius = 10
        button4.alpha = 0.0
        view.addSubview(button4)
        
        button5.setTitle("• Super", for: .normal)
        button5.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button5.setTitleColor(.systemGreen , for: .normal)
        button5.frame = CGRect(x: 155, y: 340, width: 90, height: 40)
        button5.backgroundColor = .clear
        button5.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        button5.layer.borderWidth = 2
        button5.layer.cornerRadius = 10
        button5.alpha = 0.0
        view.addSubview(button5)


        let tap = UITapGestureRecognizer(target: self, action: #selector(funzione))
        button.addGestureRecognizer(tap)
        
        let taptaco = UITapGestureRecognizer(target: self, action: #selector(funzionetaco))
        buttontaco.addGestureRecognizer(taptaco)

        let tappizza = UITapGestureRecognizer(target: self, action: #selector(funzionepizza))
        buttonpizza.addGestureRecognizer(tappizza)
        
        let tapsalad = UITapGestureRecognizer(target: self, action: #selector(funzionesalad))
        buttonsalad.addGestureRecognizer(tapsalad)
        
        let tapsandwich = UITapGestureRecognizer(target: self, action: #selector(funzionesandwich))
        buttonsandwich.addGestureRecognizer(tapsandwich)
        
        
        let tap2 = UITapGestureRecognizer(target: self, action: #selector(funzione2))
        button2.addGestureRecognizer(tap2)
        
        let tap3 = UITapGestureRecognizer(target: self, action: #selector(funzione3))
        button3.addGestureRecognizer(tap3)


        let tap4 = UITapGestureRecognizer(target: self, action: #selector(funzione4))
        button4.addGestureRecognizer(tap4)
        
        
        let tap5 = UITapGestureRecognizer(target: self, action: #selector(funzione5))
        button5.addGestureRecognizer(tap5)
        
        
        
      
        
        self.view = view
        
        }
    

    
    @objc func funzione(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene()
        case 4: fourthScene()
        case 5: fifthScene()
        case 6: sixthScene()
        default: break
        }
    }
    
    @objc func funzione2(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene2()
        default: break
        }
    }
    
    @objc func funzione3(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene3()
        default: break
        }
    }
    
    @objc func funzione4(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene4()
        default: break
        }
    }
    @objc func funzione5(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene5()
        default: break
        }
    }
    
    @objc func funzionetaco(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: tacoScene()
        case 3: thirdScene()
        default: break
        }
    }
    
    
    @objc func funzionepizza(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: pizzaScene()
        case 3: thirdScene()
        default: break
        }
    }
    
    @objc func funzionesalad(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: saladScene()
        case 3: thirdScene()
        default: break
        }
    }
    @objc func funzionesandwich(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: sandwichScene()
        case 3: thirdScene()
        default: break
        }
    }
    
    
    func firstScene () {
        playSound(sound: "Nightvision", type:"mp3")
        view.backgroundColor = .black
        eatText.text = eat
        self.view.addSubview(eatText)
        whiteroom.alpha = 0.0
        taco.alpha = 1.0
        pizza.alpha = 1.0
        salad.alpha = 1.0
        sandwich.alpha = 1.0
        button.setTitleColor(.systemGreen, for: .normal)
        button.layer.borderColor = .init(srgbRed: 0, green: 209, blue: 0, alpha: 0.7)
        button.alpha = 0.0
        buttontaco.alpha = 1.0
        buttonpizza.alpha = 1.0
        buttonsalad.alpha = 1.0
        buttonsandwich.alpha = 1.0
    }
    
    func secondScene () {
        robertText1.text = robert1[0]
        self.view.addSubview(robertText1)
        eatText.text = eat
        self.view.addSubview(eatText)
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        self.view.addSubview(animationView)
        loadingText.text = loading [0]
        self.view.addSubview(loadingText)
        buttonpizza.alpha = 0.0
        button2.alpha = 1.0
        button3.alpha = 1.0
        button4.alpha = 1.0
        button5.alpha = 1.0
        
        }
    
    
    
    func tacoScene () {
        robertText1.text = robert1[0]
        self.view.addSubview(robertText1)
        eatText.text = eat
        eatText.alpha = 0.7
        self.view.addSubview(eatText)
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        self.view.addSubview(animationView)
        loadingText.text = loading [0]
        self.view.addSubview(loadingText)
        buttonpizza.alpha = 0.0
        button2.alpha = 1.0
        button3.alpha = 1.0
        button4.alpha = 1.0
        button5.alpha = 1.0
        pizza.alpha = 0.5
        salad.alpha = 0.5
        sandwich.alpha = 0.5
        
        
        }
    func pizzaScene () {
        robertText1.text = robert1[1]
        self.view.addSubview(robertText1)
        eatText.text = eat
        self.view.addSubview(eatText)
        eatText.alpha = 0.7
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        self.view.addSubview(animationView)
        loadingText.text = loading [0]
        self.view.addSubview(loadingText)
        buttonpizza.alpha = 0.0
        button2.alpha = 1.0
        button3.alpha = 1.0
        button4.alpha = 1.0
        button5.alpha = 1.0
        taco.alpha = 0.5
        salad.alpha = 0.5
        sandwich.alpha = 0.5
        
        
        
        }
    func saladScene () {
        robertText1.text = robert1[2]
        self.view.addSubview(robertText1)
        eatText.text = eat
        eatText.alpha = 0.7
        self.view.addSubview(eatText)
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        self.view.addSubview(animationView)
        loadingText.text = loading [0]
        self.view.addSubview(loadingText)
        buttonpizza.alpha = 0.0
        button2.alpha = 1.0
        button3.alpha = 1.0
        button4.alpha = 1.0
        button5.alpha = 1.0
        pizza.alpha = 0.5
        taco.alpha = 0.5
        sandwich.alpha = 0.5
        
        
        }
    func sandwichScene () {
        robertText1.text = robert1[3]
        self.view.addSubview(robertText1)
        eatText.text = eat
        eatText.alpha = 0.7
        self.view.addSubview(eatText)
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        self.view.addSubview(animationView)
        loadingText.text = loading [0]
        self.view.addSubview(loadingText)
        buttonpizza.alpha = 0.0
        button2.alpha = 1.0
        button3.alpha = 1.0
        button4.alpha = 1.0
        button5.alpha = 1.0
        pizza.alpha = 0.5
        salad.alpha = 0.5
        taco.alpha = 0.5
        
        
        }
    func thirdScene () {
        robertText2.text = robert2
        self.view.addSubview(robertText2)
        robertText1.textColor = .darkGray
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        button.alpha = 1.0
        button.setTitle("go to sleep", for: .normal)
        button.frame = CGRect(x: 200, y: 590, width: 150, height: 50)
        loadingcompleta.alpha = 1.0
        loadingText.text = loading [1]
        animationView.alpha = 0.0

    }
    func thirdScene2 () {
        robertText2.text = robert2
        self.view.addSubview(robertText2)
        robertText1.textColor = .darkGray
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        button.alpha = 1.0
        button.setTitle("go to sleep", for: .normal)
        button.frame = CGRect(x: 200, y: 590, width: 150, height: 50)
        loadingcompleta.alpha = 1.0
        loadingText.text = loading [1]
        animationView.alpha = 0.0
        button5.alpha = 0.5
        button3.alpha = 0.5
        button4.alpha = 0.5
        domandaText.alpha = 0.7
    }
    func thirdScene3 () {
        robertText2.text = robert2
        self.view.addSubview(robertText2)
        robertText1.textColor = .darkGray
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        button.alpha = 1.0
        button.setTitle("go to sleep", for: .normal)
        button.frame = CGRect(x: 200, y: 590, width: 150, height: 50)
        loadingcompleta.alpha = 1.0
        loadingText.text = loading [1]
        animationView.alpha = 0.0
        button2.alpha = 0.5
        button5.alpha = 0.5
        button4.alpha = 0.5
        domandaText.alpha = 0.7
    }
    func thirdScene4 () {
        robertText2.text = robert2
        self.view.addSubview(robertText2)
        robertText1.textColor = .darkGray
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        button.alpha = 1.0
        button.setTitle("go to sleep", for: .normal)
        button.frame = CGRect(x: 200, y: 590, width: 150, height: 50)
        loadingcompleta.alpha = 1.0
        loadingText.text = loading [1]
        animationView.alpha = 0.0
        button2.alpha = 0.5
        button3.alpha = 0.5
        button5.alpha = 0.5
        domandaText.alpha = 0.7
    }
    
    func thirdScene5 () {
        robertText2.text = robert2
        self.view.addSubview(robertText2)
        robertText1.textColor = .darkGray
        domandaText.text = domanda
        self.view.addSubview(domandaText)
        button.alpha = 1.0
        button.setTitle("go to sleep", for: .normal)
        button.frame = CGRect(x: 200, y: 590, width: 150, height: 50)
        loadingcompleta.alpha = 1.0
        loadingText.text = loading [1]
        animationView.alpha = 0.0
        button2.alpha = 0.5
        button3.alpha = 0.5
        button4.alpha = 0.5
        domandaText.alpha = 0.7

    }
    
    func fourthScene (){
        playSound(sound: "tvsound", type:"mp3")
        bannerText.alpha = 0.0
        eatText.alpha = 0.0
        taco.alpha = 0.0
        pizza.alpha = 0.0
        salad.alpha = 0.0
        sandwich.alpha = 0.0
        loadingcompleta.alpha = 0.0
        button2.alpha = 0.0
        button3.alpha = 0.0
        button4.alpha = 0.0
        button5.alpha = 0.0
        button.alpha = 0.0
        domandaText.alpha = 0.0
        robertText1.alpha = 0.0
        robertText2.alpha = 0.0
        loadingText.alpha = 0.0
        tvView.startAnimating()
        self.view.addSubview(tvView)
    
    }
    func fifthScene (){

        

    }
    func sixthScene () {

    }
}

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
PlaygroundPage.current.needsIndefiniteExecution = true

