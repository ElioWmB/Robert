//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport
import AVFoundation

var batteryLow: AVAudioPlayer?

func batteryLow(sound: String, type: String) {
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.numberOfLoops = 3
            audioPlayer?.play()
        } catch {
            print("Non funzionaaaaaa")
        }
    }
}


var glitch2Player: AVAudioPlayer?

func glitch2Sound(sound: String, type: String) {
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.numberOfLoops = 1
            audioPlayer?.play()
        } catch {
            print("Non funzionaaaaaa")
        }
    }
}

var glitchPlayer: AVAudioPlayer?

func glitchSound(sound: String, type: String) {
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.numberOfLoops = -1
            audioPlayer?.play()
        } catch {
            print("Non funzionaaaaaa")
        }
    }
}


var audioPlayer: AVAudioPlayer?

func playSound(sound: String, type: String) {
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.play()
        } catch {
            print("Non funzionaaaaaa")
        }
    }
}


let robert1 = "[???]: Who’s Robert? Should I read\n          this message? Well, that’s not\n          for me, but here there’s no one."

let robertText1 = UILabel(frame: CGRect(x: 30, y: 145, width: 305, height: 300))


robertText1.textColor = .white
robertText1.shadowColor = .black
robertText1.shadowOffset = .init(width: 1, height: 0.5)
robertText1.backgroundColor = .clear
robertText1.font = UIFont(name: "Helvetica", size: 18)
robertText1.textAlignment = .left
robertText1.numberOfLines = 0

let robert2 = "[???]: But wait… So it means… that I\n          am Robert. I’m thinking about\n          my name but I can’t remember\n          it! How can it be?"

let robertText2 = UILabel(frame: CGRect(x: 30, y: 235, width: 300, height: 300))


robertText2.textColor = .white
robertText2.shadowColor = .black
robertText2.shadowOffset = .init(width: 1, height: 0.5)
robertText2.backgroundColor = .clear
robertText2.font = UIFont(name: "Helvetica", size: 18)
robertText2.textAlignment = .left
robertText2.numberOfLines = 0


let robert3 = "[???]: Who am I? Why am I here?\n          How could I’ve lived without\n          knowing all of these things?!\n          I’ve never cared about it. So,\n          what is my purpose? I should\n          definitely read the message."

let robertText3 = UILabel(frame: CGRect(x: 30, y: 358, width: 300, height: 300))


robertText3.textColor = .white
robertText3.shadowColor = .black
robertText3.shadowOffset = .init(width: 1, height: 0.5)
robertText3.backgroundColor = .clear
robertText3.font = UIFont(name: "Helvetica", size: 18)
robertText3.textAlignment = .left
robertText3.numberOfLines = 0


let eat = ["Mail_inbox:\nNew unread message for Robert\n(Loading...)","Mail_inbox:\nNew unread message for Robert\n    "]



let eatText = UILabel(frame: CGRect(x: 25, y: -50, width: 320, height: 300))


eatText.textColor = .systemGreen
eatText.shadowColor = .black
eatText.shadowOffset = .init(width: 1, height: 0.5)
eatText.backgroundColor = .clear
eatText.font = UIFont(name: "Courier", size: 18)
eatText.textAlignment = .left
eatText.numberOfLines = 0

let banner = "T.A.R.S.app_routine_"

let bannerText = UILabel(frame: CGRect(x:25, y: -100, width:300,height: 300))

bannerText.textColor = .systemGreen
bannerText.shadowColor = .black
bannerText.shadowOffset = .init(width: 1, height: 0.5)
bannerText.backgroundColor = .clear
bannerText.font = UIFont(name: "Courier-Bold", size: 13)
bannerText.textAlignment = .left
bannerText.numberOfLines = 0

let rebPictures: [UIImage] =
[
        UIImage(named: "reb1.png")!, UIImage(named: "reb2.png")!, UIImage(named: "reb3.png")!,
        UIImage(named:"reb2.png")!, UIImage(named: "reb1.png")!

]
var rebView = UIImageView(frame: CGRect(x: CGFloat(25), y: CGFloat(100), width: CGFloat(125.5), height: CGFloat(15.6)))
rebView.animationImages = rebPictures
rebView.animationDuration = 1.5
rebView.animationRepeatCount = 0
rebView.startAnimating()

let batPictures: [UIImage] =
[
        UIImage(named: "bat1.png")!, UIImage(named: "bat2.png")!,
        UIImage(named: "bat1.png")!, UIImage(named: "bat2.png")!,
        UIImage(named: "bat1.png")!, UIImage(named: "bat2.png")!,
        UIImage(named: "bat1.png")!, UIImage(named: "bat2.png")!,
        UIImage(named: "bat1.png")!, UIImage(named: "bat2.png")!,
        UIImage(named: "bat1.png")!, UIImage(named: "bat2.png")!,
        UIImage(named: "line1.png")!, UIImage(named: "line2.png")!,
        UIImage(named: "line3.png")!, UIImage(named: "line4.png")!,
        UIImage(named: "line5.png")!, UIImage(named: "off1.png")!,
        UIImage(named: "off1.png")!,
        UIImage(named: "off2.png")!,
        UIImage(named: "off2.png")!,
        UIImage(named: "off3.png")!,
        UIImage(named: "off3.png")!,
        UIImage(named: "off4.png")!,
        UIImage(named: "off4.png")!,
        UIImage(named: "off5.png")!,
        UIImage(named: "off5.png")!,
        UIImage(named: "off6.png")!,
        UIImage(named: "off6.png")!,
        UIImage(named: "off7.png")!,
        UIImage(named: "off7.png")!,
        UIImage(named: "tv1.png")!,  UIImage(named: "tv3.png")!,
 UIImage(named: "tv6.png")!,
        UIImage(named: "tv7.png")!,  UIImage(named: "tv9.png")!,  UIImage(named:"tv12.png")!,
        UIImage(named: "tv14.png")!,
        
        ]
var batView = UIImageView(frame: CGRect(x: CGFloat(100), y: CGFloat(300), width: CGFloat(190), height: CGFloat(73)))
batView.animationImages = batPictures
batView.animationDuration = 15
batView.animationRepeatCount = 1

let glitchPictures: [UIImage] =
[
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00001.png")!,
        UIImage(named: "glitch_00002.png")!,
        UIImage(named: "glitch_00003.png")!,
        UIImage(named: "glitch_00004.png")!,
        UIImage(named: "glitch_00005.png")!,
        UIImage(named: "glitch_00006.png")!,
        UIImage(named: "glitch_00007.png")!,
        UIImage(named: "glitch_00008.png")!,
        UIImage(named: "glitch_00009.png")!,
        UIImage(named: "glitch_00010.png")!,
        UIImage(named: "glitch_00011.png")!,
        UIImage(named: "glitch_00012.png")!,
        UIImage(named: "glitch_00013.png")!,
        UIImage(named: "glitch_00014.png")!,
        UIImage(named: "glitch_00015.png")!,
        UIImage(named: "glitch_00016.png")!,
        UIImage(named: "glitch_00017.png")!,
        UIImage(named: "glitch_00018.png")!,
        UIImage(named: "glitch_00019.png")!,
        UIImage(named: "glitch_00020.png")!,
        UIImage(named: "glitch_00021.png")!,
        UIImage(named: "glitch_00022.png")!,
        UIImage(named: "glitch_00023.png")!,
        UIImage(named: "glitch_00024.png")!,
        UIImage(named: "glitch_00025.png")!,
        UIImage(named: "glitch_00026.png")!,
        UIImage(named: "glitch_00027.png")!,
        UIImage(named: "glitch_00028.png")!,
        UIImage(named: "glitch_00029.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,


]
var glitchView = UIImageView(frame: CGRect(x: CGFloat(00), y: CGFloat(00), width: CGFloat(360), height: CGFloat(680)))
glitchView.animationImages = glitchPictures
glitchView.animationDuration = 2.5
glitchView.animationRepeatCount = 0

let glitch2Pictures: [UIImage] =
[
        UIImage(named: "glitch_00030.png")!,
        UIImage(named: "glitch_00031.png")!,
        UIImage(named: "glitch_00032.png")!,
        UIImage(named: "glitch_00033.png")!,
        UIImage(named: "glitch_00034.png")!,
        UIImage(named: "glitch_00035.png")!,
        UIImage(named: "glitch_00036.png")!,
        UIImage(named: "glitch_00037.png")!,
        UIImage(named: "glitch_00038.png")!,
        UIImage(named: "glitch_00039.png")!,
        UIImage(named: "glitch_00040.png")!,
        UIImage(named: "glitch_00041.png")!,
        UIImage(named: "glitch_00042.png")!,
        UIImage(named: "glitch_00043.png")!,
        UIImage(named: "glitch_00044.png")!,
        UIImage(named: "glitch_00045.png")!,
        UIImage(named: "glitch_00046.png")!,
        UIImage(named: "glitch_00047.png")!,
        UIImage(named: "glitch_00048.png")!,
        UIImage(named: "glitch_00049.png")!,
        UIImage(named: "glitch_00050.png")!,
        UIImage(named: "glitch_00051.png")!,
        UIImage(named: "glitch_00052.png")!,
        UIImage(named: "glitch_00053.png")!,
        UIImage(named: "glitch_00054.png")!,
        UIImage(named: "glitch_00055.png")!,
        UIImage(named: "glitch_00056.png")!,
        UIImage(named: "glitch_00057.png")!,
        UIImage(named: "glitch_00058.png")!,
        UIImage(named: "glitch_00059.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        UIImage(named: "glitch_00000.png")!,
        


]
var glitch2View = UIImageView(frame: CGRect(x: CGFloat(00), y: CGFloat(00), width: CGFloat(360), height: CGFloat(680)))
glitch2View.animationImages = glitch2Pictures
glitch2View.animationDuration = 3
glitch2View.animationRepeatCount = 2



var variable = 0

class MyViewController : UIViewController {

    var whiteroom:UIImageView!
    var messageoff:UIImageView!
    var messageon:UIImageView!
    var battery:UIImageView!
    let button = UIButton()
    let button1 = UIButton()
    let button2 = UIButton()
    let button3 = UIButton()
    let button4 = UIButton()
    let button5 = UIButton()
    let buttonmail = UIButton()

    
    
    override func loadView() {
        
        
        
        let view = UIView()
        view.backgroundColor = .black
        
        playSound(sound: "Nightvision", type:"mp3")
        
        view.addSubview(rebView)
        
        bannerText.text = banner
        view.addSubview(bannerText)
        
        
        whiteroom = UIImageView()
        whiteroom.image = UIImage(named: "untitled.png")
        whiteroom.frame = CGRect(x: -300, y: 0, width: 1000, height: 600)

        
        messageoff = UIImageView()
        messageoff.image = UIImage(named: "Message_OFF.png")
        messageoff.frame = CGRect(x: 25, y:135, width: 325, height: 47)
        view.addSubview(messageoff)
        messageoff.alpha = 0.0
        
        messageon = UIImageView()
        messageon.image = UIImage(named: "Message_ON.png")
        messageon.frame = CGRect(x: 25, y:135, width: 325, height: 432)
        view.addSubview(messageon)
        messageon.alpha = 0.0
        
        battery = UIImageView()
        battery.image = UIImage(named: "battery_low.png")
        battery.frame = CGRect(x: 100, y:300, width: 190, height: 73)
        view.addSubview(battery)
        battery.alpha = 0.0
        
        
        button.setTitle(">", for: .normal)
        button.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button.setTitleColor(.systemGreen, for: .normal)
        button.frame = CGRect(x: 300, y: 590, width: 50, height: 50)
        button.backgroundColor = .clear
        button.layer.borderColor = .init(srgbRed: 00, green: 255, blue: 00, alpha: 0.7)
        button.layer.borderWidth = 2
        button.layer.cornerRadius = 10
        
        view.addSubview(button)
        
        button1.setTitle("  ", for: .normal)
        button1.titleLabel?.font = UIFont(name: "Courier", size: 18)
        button1.setTitleColor(.green, for: .normal)
        button1.frame = CGRect(x: 35, y: 130, width: 300, height: 60)
        button1.backgroundColor = .clear
        button1.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        button1.layer.borderWidth = 2
        button1.layer.cornerRadius = 10
        button1.alpha = 0.0
        
        view.addSubview(button1)
        
        buttonmail.setTitle("  ", for: .normal)
        buttonmail.titleLabel?.font = UIFont(name: "Courier", size: 18)
        buttonmail.setTitleColor(.green, for: .normal)
        buttonmail.frame = CGRect(x: 25, y: 155, width: 325, height: 47)
        buttonmail.backgroundColor = .clear
        buttonmail.layer.borderColor = .init(srgbRed: 0, green: 255, blue: 0, alpha: 0.0)
        buttonmail.layer.borderWidth = 2
        buttonmail.layer.cornerRadius = 10
        buttonmail.alpha = 0.0
        
        view.addSubview(buttonmail)
        
      


        let tap = UITapGestureRecognizer(target: self, action: #selector(funzione))
        button.addGestureRecognizer(tap)


        let tap1 = UITapGestureRecognizer(target: self, action: #selector(funzione))
        button1.addGestureRecognizer(tap1)
        
        
        let tap2 = UITapGestureRecognizer(target: self, action: #selector(funzione2))
        button2.addGestureRecognizer(tap2)
        
        let tap3 = UITapGestureRecognizer(target: self, action: #selector(funzione2))
        button3.addGestureRecognizer(tap3)


        let tap4 = UITapGestureRecognizer(target: self, action: #selector(funzione2))
        button4.addGestureRecognizer(tap4)
        
        
        let tap5 = UITapGestureRecognizer(target: self, action: #selector(funzione2))
        button5.addGestureRecognizer(tap5)
        
        let tap6 = UITapGestureRecognizer(target: self, action: #selector(funzione))
        buttonmail.addGestureRecognizer(tap6)
        
      
        
        self.view = view
        
        }
    
    
    @objc func funzione(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene()
        case 4: fourthScene()
        case 5: fifthScene()
        case 6: sixthScene()
        default: break
        }
    }
    
    @objc func funzione2(){
          variable += 1
        switch variable {
        case 1: firstScene()
        case 2: secondScene()
        case 3: thirdScene()
        default: break
        }
    }
    
    
    func firstScene () {
        
        rebView.alpha = 0.0
        view.backgroundColor = .black
        bannerText.text = banner
        self.view.addSubview(bannerText)
        eatText.text = eat[0]
        self.view.addSubview(eatText)
        whiteroom.alpha = 0.0
        messageoff.alpha = 0.0
        button.setTitleColor(.systemGreen, for: .normal)
        button.layer.borderColor = .init(srgbRed: 0, green: 209, blue: 0, alpha: 0.7)
        button1.alpha = 1.0
        button.alpha = 1.0
        button.setTitle(">", for: .normal)
        button.frame = CGRect(x: 300, y: 590, width: 50, height: 50)
        robertText1.text = robert1
        self.view.addSubview(robertText1)
    }
    
    func secondScene () {
        robertText1.text = robert1
        self.view.addSubview(robertText1)
        robertText1.textColor = .darkGray
        robertText2.text = robert2
        self.view.addSubview(robertText2)
        eatText.text = eat[0]
        self.view.addSubview(eatText)
        messageoff.alpha = 0.0
        button1.alpha = 0.0
        button2.alpha = 1.0
        button3.alpha = 1.0
        button4.alpha = 1.0
        button5.alpha = 1.0
        button.alpha = 1.0
        button.setTitle(">", for: .normal)
        button.frame = CGRect(x: 300, y: 590, width: 50, height: 50)
        glitchView.startAnimating()
        self.view.addSubview(glitchView)
        glitchSound(sound: "glitch", type:"mp3")
        }
    
    func thirdScene () {
        
        robertText2.textColor = .darkGray
        robertText1.textColor = .darkGray
        robertText3.text = robert3
        self.view.addSubview(robertText3)
        button.alpha = 0.0
        button.setTitle(">", for: .normal)
        button.frame = CGRect(x: 300, y: 590, width: 50, height: 50)
        eatText.text = eat[1]
        self.view.addSubview(eatText)
        messageoff.alpha = 1.0
        buttonmail.alpha = 1.0
    }
    func fourthScene (){
        glitch2Sound(sound: "glitch", type:"mp3")
        
        glitchView.alpha = 0.0
        glitch2View.startAnimating()
        self.view.addSubview(glitch2View)
        eatText.text = eat[1]
        messageon.alpha = 1.0
        messageoff.alpha = 0.0
        button.alpha = 1.0
        robertText1.alpha = 0.0
        robertText2.alpha = 0.0
        robertText3.alpha = 0.0
        
    
    
        self.view.addSubview(eatText)
        
//        UIView.animate(withDuration: 2.0, delay : 0.0 , options : [.repeat,.autoreverse] ,animations: {
//
//        }, completion: nil );

    }
    func fifthScene (){
        battery.alpha = 0.0
        messageon.alpha = 0.0
        button.alpha = 0.0
        bannerText.alpha = 0.0
        eatText.alpha = 0.0
        batView.startAnimating()
        view.addSubview(batView)
        batteryLow(sound: "Low Battery Sound", type: "mp3")
        
        
//        eatText.text = eat
//        self.view.addSubview(eatText)
    }
    func sixthScene () {
        bannerText.alpha = 0.0
        eatText.alpha = 0.0
        button2.alpha = 0.0
        button3.alpha = 0.0
        button4.alpha = 0.0
        button5.alpha = 0.0
        button.alpha = 0.0
        robertText1.alpha = 0.0
        robertText2.alpha = 0.0

    }
}

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
PlaygroundPage.current.needsIndefiniteExecution = true
